const form = document.getElementById('carbon-footprint-form');
const resultsElement = document.getElementById('results');

form.addEventListener('submit', function(event) {
  event.preventDefault();

  // Get monthly usage values
  const averageMonthlyElectricityUsage = parseFloat(document.getElementById('electricity-usage').value);
  const averageMonthlyGasUsage = parseFloat(document.getElementById('gas-usage').value);
  const averageMonthlyWaterUsage = parseFloat(document.getElementById('water-usage').value);
  const monthlyWasteGeneration = parseFloat(document.getElementById('waste-generation').value);
  const numberOfPersons = parseInt(document.getElementById('persons').value) || 1;

  // Emission factors (Worldwide averages)
  const electricityEmissionFactor = 0.475; // kg CO2e per kWh (Worldwide average for electricity)
  const gasEmissionFactor = 1.9; // kg CO2e per cubic meter (Worldwide average for natural gas)
  const waterEmissionFactor = 0.2; // kg CO2e per cubic meter (Worldwide average for water)
  const wasteEmissionFactor = 0.42; // kg CO2e per kg of waste (Worldwide average for waste)

  // Calculate monthly carbon footprint for each category
  const monthlyElectricityFootprint = calculateCarbonFootprint(averageMonthlyElectricityUsage, electricityEmissionFactor);
  const monthlyGasFootprint = calculateCarbonFootprint(averageMonthlyGasUsage, gasEmissionFactor);
  const monthlyWaterFootprint = calculateCarbonFootprint(averageMonthlyWaterUsage, waterEmissionFactor);
  const monthlyWasteFootprint = calculateCarbonFootprint(monthlyWasteGeneration, wasteEmissionFactor);

  // Calculate total monthly footprint including the number of persons
  const totalMonthlyFootprint = (monthlyElectricityFootprint + monthlyGasFootprint + monthlyWaterFootprint + monthlyWasteFootprint) / numberOfPersons;

  // Display results with units
  const results = `
    <h3>Monthly Carbon Footprint for ${numberOfPersons} People</h3>
    <ul>
      <li>Electricity: ${monthlyElectricityFootprint.toFixed(2)} kg CO2e per month</li>
      <li>Gas: ${monthlyGasFootprint.toFixed(2)} kg CO2e per month</li>
      <li>Water: ${monthlyWaterFootprint.toFixed(2)} kg CO2e per month</li>
      <li>Waste: ${monthlyWasteFootprint.toFixed(2)} kg CO2e per month</li>
    </ul>
    <p><strong>Total: ${totalMonthlyFootprint.toFixed(2)} kg CO2e per month</strong></p>
  `;

  resultsElement.innerHTML = results;
});

function calculateCarbonFootprint(usage, emissionFactor) {
  return usage * emissionFactor;
}
